
# Shaman BiS List
## Restoration Shaman

|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Frost Witch's Headpiece](https://wotlk.evowow.com/?item=50724)             | Vendor                     |
| Neck            | [Blood Queen's Crimson Choker](https://wotlk.evowow.com/?item=50724)                   | Blood Queen Lana'thel 25HC |
| Shoulders       | [Sanctified Frost Witch's Spaulders](https://wotlk.evowow.com/?item=51245)             | Vendor                     |
| Back            | [Cloak of Burning Dusk](https://wotlk.evowow.com/?item=54583)                          | Halion 25HC                |
| Chest           | [Sanctified Frost Witch's Tunic](https://wotlk.evowow.com/?item=51249)                 | Vendor                     |
| Wrists          | [Bloodsunder's Bracers](https://wotlk.evowow.com/?item=50687)                          | Rotface 25HC               |
| Hands           | [Unclean Surgical Gloves](https://wotlk.evowow.com/?item=50703)                        | Festergut 25HC             |
| Waist           | [Split Shape Belt](https://wotlk.evowow.com/?item=54587)                               | Halion 25HC                |
| Legs            | [Sanctified Frost Witch's Legguards](https://wotlk.evowow.com/?item=51246)             | Vendor                     |
| Feet            | [Plague Scientist's Boots](https://wotlk.evowow.com/?item=50699)                       | Festergut 25HC             |
| Finger          | [Ring of Rapid Ascent](https://wotlk.evowow.com/?item=50664)                           | Gunship Battle 25HC        |
| Finger          | [Ashen Band of Endless Wisdom](https://wotlk.evowow.com/?item=50400)                   | Vendor                     |
| Trinket         | [Althor's Abacus](https://wotlk.evowow.com/?item=50366)                                | Gunship Battle 25HC        |
| Trinket         | [Glowing Twilight Scale](https://wotlk.evowow.com/?item=54589)                         | Halion 25HC                |
| Main Hand       | [Val'anyr, Hammer of Ancient Kings](https://wotlk.evowow.com/?item=46017)              | Ulduar Quest Line          |
| Main Hand (Alt) | [Trauma](https://wotlk.evowow.com/?item=50685)                                         | Rotface 25HC               |
| Off Hand        | [Bulwark of Smouldering Steel](https://wotlk.evowow.com/?item=50616)                   | Marrowgar 25HC             |
| Totem           | [Bizuri's Totem of Shattered Ice](https://wotlk.evowow.com/?item=50458)                | Vendor                     |


## Elemental Shaman
| Slot            | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Frost Witch's Helm](https://wotlk.evowow.com/?item=51237)                  | Vendor                     |
| Neck            | [Blood Queen's Crimson Choker](https://wotlk.evowow.com/?item=50724)                   | Blood Queen Lana'thel 25HC |
| Shoulders       | [Sanctified Frost Witch's Shoulderpads](https://wotlk.evowow.com/?item=51235)          | Vendor                     |
| Back            | [Cloak of Burning Dusk](https://wotlk.evowow.com/?item=54583)                          | Halion 25HC                |
| Chest           | [Sanctified Frost Witch's Hauberk](https://wotlk.evowow.com/?item=51239)               | Vendor                     |
| Wrists          | [Bracers of Fiery Night](https://wotlk.evowow.com/?item=54582)                         | Halion 25HC                |
| Hands           | [Sanctified Frost Witch's Gloves](https://wotlk.evowow.com/?item=51238)                | Vendor                     |
| Waist           | [Split Shape Belt](https://wotlk.evowow.com/?item=54587)                               | Halion 25HC                |
| Legs            | [Plaguebringer's Stained Pants](https://wotlk.evowow.com/?item=50694)                  | Festergut 25HC             |
| Feet            | [Plague Scientist's Boots](https://wotlk.evowow.com/?item=50699)                       | Festergut 25HC             |
| Finger          | [Ring of Rapid Ascent](https://wotlk.evowow.com/?item=50664)                           | Gunship 25HC               |
| Finger          | [Ashen Band of Endless Destruction](https://wotlk.evowow.com/?item=50398)              | Vendor                     |
| Trinket         | [Charred Twilight Scale](https://wotlk.evowow.com/?item=54588)                         | Halion 25HC                |
| Trinket         | [Phylactery of the Nameless Lich](https://wotlk.evowow.com/?item=50365)                | Sindragosa 25HC            |
| Main Hand       | [Royal Scepter of Terenas II](https://wotlk.evowow.com/?item=50734)                    | Lich King 25HC             |
| Off Hand        | [Bulwark of Smouldering Steel](https://wotlk.evowow.com/?item=50616)                   | Marrowgar 25HC             |
| Totem           | [Bizuri's Totem of Shattered Ice](https://wotlk.evowow.com/?item=50458)                | Vendor                     |

## Enhancement Shaman

|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Frost Witch's Faceguard](https://wotlk.evowow.com/?item=51242)             | Vendor                     |
| Neck            | [Sindragosa's Cruel Claw](https://wotlk.evowow.com/?item=50633)                        | Sindragosa 25HC            |
| Shoulders       | [Sanctified Frost Witch's Shoulderguards](https://wotlk.evowow.com/?item=51240)        | Vendor                     |
| Back            | [Shadowvault Slayer's Cloak](https://wotlk.evowow.com/?item=50653)                     | Gunship Battle 25HC        |
| Chest           | [Carapace of Forgotten Kings](https://wotlk.evowow.com/?item=50689)                    | Festergut 25HC             |
| Wrists          | [Scourge Hunter's Vambraces](https://wotlk.evowow.com/?item=50655)                     | Gunship Battle 25HC        |
| Hands           | [Sanctified Frost Witch's Grips](https://wotlk.evowow.com/?item=51243)                 | Vendor                     |
| Waist           | [Nerub'ar Stalker's Cord](https://wotlk.evowow.com/?item=50688)                        | Festergut 25HC             |
| Legs            | [Sanctified Frost Witch's War-Kilt](https://wotlk.evowow.com/?item=51241)              | Vendor                     |
| Feet            | [Returning Footfalls](https://wotlk.evowow.com/?item=54577)                            | Halion 25HC                |
| Finger          | [Seal of Many Mouths](https://wotlk.evowow.com/?item=50678)                            | Rotface 25HC               |
| Finger          | [Ashen Band of Endless Vengeance](https://wotlk.evowow.com/?item=50402)                | ICC Reputation             |
| Trinket         | [Tiny Abomination in a Jar](https://wotlk.evowow.com/?item=50706)                      | Professor Putricide 25HC   |
| Trinket         | [Sharpened Twilight Scale](https://wotlk.evowow.com/?item=54590)                       | Halion 25HC                |
| Main Hand       | [Havoc's Call, Blade of Lordaeron Kings](https://wotlk.evowow.com/?item=50737)         | Lich King 25HC             |
| Off Hand        | [Havoc's Call, Blade of Lordaeron Kings](https://wotlk.evowow.com/?item=50737)         | Lich King 25HC             |
| Totem           | [Totem of the Avalanche](https://wotlk.evowow.com/?item=50463)                         | Vendor                     |

# Druid BiS List

## Restoration Druid
| Slot            | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Lasherweave Helmet](https://wotlk.evowow.com/?item=51302)                  | Vendor                     |
| Neck            | [Bone Sentinel's Amulet](https://wotlk.evowow.com/?item=50609)                         | Marrowgar 25HC             |
| Shoulders       | [Sanctified Lasherweave Pauldrons](https://wotlk.evowow.com/?item=51304)               | Vendor                     |
| Back            | [Greatcloak of the Turned Champion](https://wotlk.evowow.com/?item=50668)              | Deathbringer Saurfang 25HC |
| Chest           | [Sanguine Silk Robes](https://wotlk.evowow.com/?item=50717)                            | Prince Valanar 25HC        |
| Bracers         | [Phaseshifter Bracers](https://wotlk.evowow.com/?item=54584)                           | Halion 25HC                |
| Bracers (Alt)   | [Bracers of Eternal Dreaming](https://wotlk.evowow.com/?item=50630)                    | Valithria Dreamwalker 25HC |
| Gloves          | [Sanctified Lasherweave Gauntlets](https://wotlk.evowow.com/?item=51301)               | Vendor                     |
| Waist           | [Professor's Bloodied Smock](https://wotlk.evowow.com/?item=50705)                     | Professor Putricide 25HC   |
| Legs            | [Sanctified Lasherweave Legplates](https://wotlk.evowow.com/?item=51303)               | Vendor                     |
| Feet            | [Boots Of Unnatural Growth](https://wotlk.evowow.com/?item=50665)                      | Gunship Battle 25HC        |
| Finger          | [Ashen Band of Endless Wisdom](https://wotlk.evowow.com/?item=50400)                   | Vendor                     |
| Finger          | [Memory of Malygos](https://wotlk.evowow.com/?item=50636)                              | Sindragosa 25HC            |
| Trinket         | [Solace of the Defeated](https://wotlk.evowow.com/?item=47059)                         | Lord Jaraxxus 25HC         |
| Trinket         | [Glowing Twilight Scale](https://wotlk.evowow.com/?item=54589)                         | Halion 25HC                |
| Trinket (Alt)   | [Althor's Abacus](https://wotlk.evowow.com/?item=50366)                                | Gunship Battle 25HC        |
| Main Hand       | [Val'anyr, Hammer of Ancient Kings](https://wotlk.evowow.com/?item=46017)              | Ulduar Quest Line          |
| Main Hand (Alt) | [Trauma](https://wotlk.evowow.com/?item=50685)                                         | Rotface 25HC               |
| Main Hand (Alt) | [Royal Scepter of Terenas II](https://wotlk.evowow.com/?item=50734)                    | Lich King 25HC             |
| Off Hand        | [Sundial of Eternal Dusk](https://wotlk.evowow.com/?item=50635)                        | Sindragosa 25HC            |
| Idol            | [Idol of the Black Willow](https://wotlk.evowow.com/?item=50454)                       | Vendor                     |

## Feral Druid Tank
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Lasherweave Headguard](https://wotlk.evowow.com/?item=51296)               | Vendor                     |
| Neck            | [Bile-Encrusted Medallion](https://wotlk.evowow.com/?item=50682)                       | Rotface 25HC               |
| Shoulders       | [Sanctified Lasherweave Shoulderpads](https://wotlk.evowow.com/?item=51299)            | Vendor                     |
| Back            | [Sentinel's Winter Cloak](https://wotlk.evowow.com/?item=50466)                        | Vendor                     |
| Chest           | [Ikfirus's Sack of Wonder](https://wotlk.evowow.com/?item=50656)                       | Gunship Battle 25HC        |
| Wrists          | [Umbrage Armbands](https://wotlk.evowow.com/?item=54580)                               | Halion 25HC                |
| Wrists (Alt)    | [Toskk's Maximized Wristguards](https://wotlk.evowow.com/?item=50670)                  | Deathbringer Saurfang 25HC |
| Hands           | [Sanctified Lasherweave Handgrips](https://wotlk.evowow.com/?item=51295)               | Vendor                     |
| Waist           | [Astrylian's Sutured Cinch](https://wotlk.evowow.com/?item=50707)                      | Professor Putricide 25HC   |
| Legs            | [Sanctified Lasherweave Legguards](https://wotlk.evowow.com/?item=51297)               | Vendor                     |
| Feet            | [Frostbitten Fur Boots](https://wotlk.evowow.com/?item=50607)                          | Marrowgar 25HC             |
| Feet (Alt)      | [Footpads of Impending Death](https://wotlk.evowow.com/?item=49895)                    | Crafted                    |
| Finger          | [Devium's Eternally Cold Ring](https://wotlk.evowow.com/?item=50622)                   | Valithria Dreamwalker 25HC |
| Finger (Alt)    | [Signet of Twilight](https://wotlk.evowow.com/?item=54576)                             | Halion 25HC                |
| Finger (Alt)    | [Seal of Many Mouths](https://wotlk.evowow.com/?item=50678)                            | Rotface 25HC               |
| Finger          | [Ashen Band of Endless Courage](https://wotlk.evowow.com/?item=50404)                  | Vendor                     |
| Trinket         | [Sindragosa's Flawless Fang](https://wotlk.evowow.com/?item=50364)                     | Sindragosa 25HC            |
| Trinket         | [Corroded Skeleton Key](https://wotlk.evowow.com/?item=50356)                          | Vendor                     |
| Trinket (Alt)   | [Unidentifiable Organ](https://wotlk.evowow.com/?item=50344)                           | Professor Putricide 10HC   |
| Main Hand       | [Oathbinder, Charge of the Range-General](https://wotlk.evowow.com/?item=50735)        | Lich King 25HC             |
| Idol            | [Idol of the Crying Moon](https://wotlk.evowow.com/?item=50456)                        | Vendor                     |

## Feral Druid DPS
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Lasherweave Headguard](https://wotlk.evowow.com/?item=51296)               | Vendor                     |
| Neck            | [Sindragosa's Cruel Claw](https://wotlk.evowow.com/?item=50633)                        | Sindragosa 25HC            |
| Shoulders       | [Sanctified Lasherweave Shoulderpads](https://wotlk.evowow.com/?item=51299)            | Vendor                     |
| Back            | [Shadowvault Slayer's Cloak](https://wotlk.evowow.com/?item=50653)                     | Gunship Battle 25HC        |
| Back (Alt)      | [Vereesa's Dexterity](https://wotlk.evowow.com/?item=47545)                            | TOGC 25 Insanity 50        |
| Chest           | [Sanctified Lashwerweave Raiment](https://wotlk.evowow.com/?item=51298)                | Vendor                     |
| Wrists          | [Toskk's Maximised Wristguards](https://wotlk.evowow.com/?item=50670)                  | Deathbringer Saurfang 25HC |
| Wrists (Alt)    | [Umbrage Armbands](https://wotlk.evowow.com/?item=54580)                               | Halion 25HC                |
| Hands           | [Aldriana's Gloves of Secrecy](https://wotlk.evowow.com/?item=50675)                   | Rotface 25HC               |
| Waist           | [Astrylian's Sutured Cinch](https://wotlk.evowow.com/?item=50707)                      | Professor Putricide 25HC   |
| Waist (Alt)     | [Vengeful Noose](https://wotlk.evowow.com/?item=50995)                                 | Vendor                     |
| Legs            | [Sanctified Lasherweave Legguards](https://wotlk.evowow.com/?item=51297)               | Vendor                     |
| Feet            | [Frostbitten Fur Boots](https://wotlk.evowow.com/?item=50607)                          | Marrowgar 25HC             |
| Feet (Alt)      | [Footpads of Impending Death](https://wotlk.evowow.com/?item=49895)                    | Crafted                    |
| Finger          | [Frostbrood Sapphire Ring](https://wotlk.evowow.com/?item=50618)                       | Valithria Dreamwalker 25HC |
| Finger (Alt)    | [Signet of Twilight](https://wotlk.evowow.com/?item=54576)                             | Halion 25HC                |
| Finger          | [Ashen Band of Endless Vengeance](https://wotlk.evowow.com/?item=50402)                | ICC Reputation             |
| Trinket         | [Deathbringer's Will](https://wotlk.evowow.com/?item=50363)                            | Deathbringer Saurfang 25HC |
| Trinket         | [Sharpened Twilight Scale](https://wotlk.evowow.com/?item=54590)                       | Halion 25HC                |
| Main Hand       | [Oathbinder, Charge of the Range-General](https://wotlk.evowow.com/?item=50735)        | Lich King 25HC             |
| Idol            | [Idol of the Crying Moon](https://wotlk.evowow.com/?item=50456)                        | Vendor                     |


## Balance Druid
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Lasherweave Cover](https://wotlk.evowow.com/?item=51290)                   | Vendor                     |
| Neck            | [Blood Queen's Crimson Choker](https://wotlk.evowow.com/?item=50724)                   | Blood Queen Lana'thel 25HC |
| Shoulders       | [Sanctified Lasherweave Mantle](https://wotlk.evowow.com/?item=51292)                  | Vendor                     |
| Back            | [Cloak of Burning Dusk](https://wotlk.evowow.com/?item=54583)                          | Halion 25HC                |
| Chest           | [Sanctified Lasherweave Vestment](https://wotlk.evowow.com/?item=51294)                | Vendor                     |
| Wrists          | [Bracers of Fiery Night](https://wotlk.evowow.com/?item=54582)                         | Halion 25HC                |
| Hands           | [Sanctified Lasherweave Gloves](https://wotlk.evowow.com/?item=51291)                  | Vendor                     |
| Waist           | [Crushing Coldwraith Belt](https://wotlk.evowow.com/?item=50613)                       | Marrowgar 25HC             |
| Legs            | [Plaguebringer's Stained Pants](https://wotlk.evowow.com/?item=50694)                  | Festergut 25HC             |
| Feet            | [Plague Scientist's Boots](https://wotlk.evowow.com/?item=50699)                       | Festergut 25HC             |
| Finger          | [Ashen Band of Endless Destruction](https://wotlk.evowow.com/?item=50398)              | Vendor                     |
| Finger          | [Valanar's Other Signet Ring](https://wotlk.evowow.com/?item=50613)                    | Prince Valanar 25HC        |
| Trinket         | [Charred Twilight Scale](https://wotlk.evowow.com/?item=54588)                         | Halion 25HC                |
| Trinket         | [Phylactery of the Nameless Lich](https://wotlk.evowow.com/?item=50365)                | Sindragosa 25HC            |
| Main Hand       | [Royal Scepter of Terenas II](https://wotlk.evowow.com/?item=50734)                    | Lich King 25HC             |
| Off Hand        | [Shadow Silk Spindle](https://wotlk.evowow.com/?item=50719)                            | Prince Valanar 25HC        |
| Idol            | []()                                                                                   |                            |


## Hunter BiS List
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Ahn'Kahar Blood Hunter's Headpiece](https://wotlk.evowow.com/?item=51286)  | Vendor                     |
| Neck            | [Sindragosa's Cruel Claw](https://wotlk.evowow.com/?item=50633)                        | Sindragosa 25HC            |
| Shoulders       | [Sanctified Ahn'Kahar Blood Hunter's Spaulders](https://wotlk.evowow.com/?item=51288)  | Vendor                     |
| Back            | [Vereesa's Dexterity](https://wotlk.evowow.com/?item=47545)                            | TOGC 25 Insanity 50        |
| Back            | [Shadowvault Slayer's Cloak](https://wotlk.evowow.com/?item=50653)                     | Gunship Battle 25HC        |
| Chest           | [Sanctified Ahn'Kahar Blood Hunter's Tunic](https://wotlk.evowow.com/?item=51289)      | Vendor                     |
| Wrists          | [Scourge Hunter's Vambraces](https://wotlk.evowow.com/?item=50655)                     | Gunship Battle 25HC        |
| Hands           | [Sanctified Ahn'Kahar Blood Hunter's Handguards](https://wotlk.evowow.com/?item=51285) | Vendor                     |
| Waist           | [Nerub'ar Stalker's Cord](https://wotlk.evowow.com/?item=50688)                        | Festergut 25HC             |
| Legs            | [Leggings of Northern Lights](https://wotlk.evowow.com/?item=50645)                    | Lady Deathwhisper 25HC     |
| Feet            | [Returning Footfalls](https://wotlk.evowow.com/?item=54577)                            | Halion 25HC                |
| Finger          | [Signet of Twilight](https://wotlk.evowow.com/?item=54576)                             | Halion 25HC                |
| Finger (Alt)    | [Frostbrood Sapphire Ring](https://wotlk.evowow.com/?item=50618)                       | Valithria Dreamwalker 25HC |
| Finger          | [Ashen Band of Endless Vengeance](https://wotlk.evowow.com/?item=50402)                | ICC Reputation             |
| Trinket         | [Deathbringer's Will](https://wotlk.evowow.com/?item=50363)                            | Deathbringer Saurfang 25HC |
| Trinket         | [Sharpened Twilight Scale](https://wotlk.evowow.com/?item=54590)                       | Halion 25HC                |
| Main Hand       | [Oathbinder, Charge of the Range-General](https://wotlk.evowow.com/?item=50735)        | Lich King 25HC             |
| Ranged          | [Fal'inrush, Defender of Quel'thalas](https://wotlk.evowow.com/?item=50733)            | Lich King 25HC             |

# Warrior BiS List
## Arms and Fury Warrior
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Ymirjar Lord's Helmet](https://wotlk.evowow.com/?item=51227)               | Vendor                     |
| Neck            | [Penumbra Pendant](https://wotlk.evowow.com/?item=54581)                               | Halion 25HC                |
| Shoulders       | [Sanctified Ymirjar Lord's Shoulderplates](https://wotlk.evowow.com/?item=51229)       | Vendor                     |
| Back            | [Vereesa's Dexterity](https://wotlk.evowow.com/?item=47545)                            | TOGC 25 Insanity 50        |
| Back (Alt)      | [Winding Sheet](https://wotlk.evowow.com/?item=50677)                                  | Rotface 25HC               |
| Chest           | [Sanctified Ymirjar Lord's Battleplate](https://wotlk.evowow.com/?item=51225)          | Vendor                     |
| Wrists          | [Toskk's Maximised Wristguards](https://wotlk.evowow.com/?item=50670)                  | Deathbringer Saurfang 25HC |
| Hands           | [Aldriana's Gloves of Secrecy](https://wotlk.evowow.com/?item=50675)                   | Rotface 25HC               |
| Waist           | [Coldwraith Links](https://wotlk.evowow.com/?item=50620)                               | Valithria Dreamwalker 25HC |
| Legs            | [Sanctified Ymirjar Lord's Legplates](https://wotlk.evowow.com/?item=51228)            | Vendor                     |
| Feet            | [Apocalypse's Advance](https://wotlk.evowow.com/?item=54578)                           | Halion 25HC                |
| Feet (Alt)      | [Blood-Soaked Saronite Stompers](https://wotlk.evowow.com/?item=50639)                 | Lady Deathwhisper 25HC     |
| Finger          | [Skeleton Lord's Circle](https://wotlk.evowow.com/?item=50657)                         | Gunship Battle 25HC        |
| Finger          | [Ashen Band of Endless Might](https://wotlk.evowow.com/?item=52572)                    | ICC Reputation             |
| Trinket         | [Deathbringer's Will](https://wotlk.evowow.com/?item=50363)                            | Deathbringer Saurfang 25HC |
| Trinket         | [Sharpened Twilight Scale](https://wotlk.evowow.com/?item=54590)                       | Halion 25HC                |
| Main Hand       | [Shadowmourne](https://wotlk.evowow.com/?item=49623)                                   | Shadowmourne Questline     |
| Main Hand (Alt) | [Glorenzelg, High-Blade of the Silver Hand](https://wotlk.evowow.com/?item=50730)      | Lich King 25HC             |
| Off Hand        | [Cryptmaker](https://wotlk.evowow.com/?item=50603)                                     | Prince Valanar 25HC        |
| Ranged          | [Fal'inrush, Defender of Quel'thalas](https://wotlk.evowow.com/?item=50733)            | Lich King 25HC             |

**Arms Warriors take one weapon off of the list, and you should be using Shadowmourne or Cryptmaker.**     

## Protection Warrior
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Broken Ram Skull Helm](https://wotlk.evowow.com/?item=50640)                          | Lady Deathwhisper 25HC     |
| Neck            | [Bile-Encrusted Medallion](https://wotlk.evowow.com/?item=50682)                       | Rotface 25HC               |
| Shoulders       | [Spaulders of the Blood Princes](https://wotlk.evowow.com/?item=51847)                 | Prince Valandar 10HC       |
| Back            | [Sentinel's Winter Cloak](https://wotlk.evowow.com/?item=50466)                        | Vendor                     |
| Chest           | [Sanctified Ymirjar Lord's Breastplate](https://wotlk.evowow.com/?item=51220)          | Vendor                     |
| Wrists          | [Gargoyle Spit Bracers](https://wotlk.evowow.com/?item=51901)                          | Deathbringer Saurfang 25HC |
| Hands           | [Sanctified Ymirjar Lord's Handguards](https://wotlk.evowow.com/?item=51222)           | Vendor                     |
| Waist           | [Belt of Broken Bones](https://wotlk.evowow.com/?item=50691)                           | Festergut 25HC             |
| Legs            | [Legguards of Lost Hope](https://wotlk.evowow.com/?item=50612)                         | Marrowgar 25HC             |
| Feet            | [Treads of Impending Resurrection](https://wotlk.evowow.com/?item=54579)               | Halion 25HC                |
| Finger          | [Devium's Eternally Cold Ring](https://wotlk.evowow.com/?item=50622)                   | Valithria Dreamwalker 25HC |
| Finger          | [Ashen Band of Endless Courage](https://wotlk.evowow.com/?item=50404)                  | Vendor                     |
| Trinket         | [Petrified Twilight Scale](https://wotlk.evowow.com/?item=54591)                       | Halion 25HC                |
| Trinket         | [Sindragosa's Flawless Fang](https://wotlk.evowow.com/?item=50364)                     | Sindragosa 25HC            |
| Trinket (Alt)   | [Unidentifiable Organ](https://wotlk.evowow.com/?item=50344)                           | Professor Putricide 10HC   |
| Trinket (Alt)   | [Corroded Skeleton Key](https://wotlk.evowow.com/?item=50356)                          | Vendor                     |
| Trinket (Alt)   | [Corpse Tongue Coin](https://wotlk.evowow.com/?item=50349)                             | Gunship Battle 25HC        |
| Main Hand       | [Mithrios, Bronzebeard's Legacy](https://wotlk.evowow.com/?item=50738)                 | Lich King 25HC             |
| Off Hand        | [Icecrown Glacial Wall](https://wotlk.evowow.com/?item=50729)                          | Blood Queen Lana'thel 25HC |
| Ranged          | [Dreamhunter's Carbine](https://wotlk.evowow.com/?item=51834)                          | Valithria Dreamwalker 25HC |

**Trinket Alternative Options Breakdown:**

|  Item                 | Purpose             |
|-----------------------|---------------------|
| Unidentifiable Organ  | Armor               |
| Corroded Skeleton Key | Stamina/Easy to get |
| Corpse Tongue Coin    | Avoidance           |


# Warlock BiS List

|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Dark Coven Hood](https://wotlk.evowow.com/?item=51231)                     | Vendor                     |
| Neck            | [Blood Queen's Crimson Choker](https://wotlk.evowow.com/?item=50724)                   | Blood Queen Lana'thel 25HC |
| Shoulders       | [Sanctified Dark Coven Shoulderpads](https://wotlk.evowow.com/?item=51234)             | Vendor                     |
| Back            | [Cloak of Burning Dusk](https://wotlk.evowow.com/?item=54583)                          | Halion 25HC                |
| Chest           | [Sanctified Dark Coven Robe](https://wotlk.evowow.com/?item=51233)                     | Vendor                     |
| Wrists          | [Bracers of Fiery Night](https://wotlk.evowow.com/?item=54582)                         | Halion 25HC                |
| Hands           | [Sanctified Dark Coven Gloves](https://wotlk.evowow.com/?item=51230)                   | Vendor                     |
| Waist           | [Crushing Coldwraith Belt](https://wotlk.evowow.com/?item=50613)                       | Marrowgar 25HC             |
| Legs            | [Plaguebringer's Stained Pants](https://wotlk.evowow.com/?item=50694)                  | Festergut 25HC             |
| Feet            | [Plague Scientist's Boots](https://wotlk.evowow.com/?item=50699)                       | Festergut 25HC             |
| Finger          | [Loop of the Endless Labyrinth](https://wotlk.evowow.com/?item=50614)                  | Marrowgar 25HC             |
| Finger          | [Ring of Rapid Ascent](https://wotlk.evowow.com/?item=50664)                           | Gunship Battle 25HC        |
| Finger          | [Ashen Band of Endless Destruction](https://wotlk.evowow.com/?item=50398)              | Vendor                     |
| Trinket         | [Charred Twilight Scale](https://wotlk.evowow.com/?item=54588)                         | Halion 25HC                |
| Trinket         | [Phylactery of the Nameless Lich](https://wotlk.evowow.com/?item=50365)                | Sindragosa 25HC            |
| Main Hand       | [Bloodsurge, Kel'Thuzad's Blade of Agony](https://wotlk.evowow.com/?item=50732)        | Lich King 25HC             |
| Off Hand        | [Shadow Silk Spindle](https://wotlk.evowow.com/?item=50719)                            | Prince Valanar 25HC        |
| Wand            | [Corpse-Impaling Spike](https://wotlk.evowow.com/?item=50684)                          | Rotface 25HC               |

# Death Knight BiS List

## Frost Death Knight
**(Blood DPS will follow the same gear, other than using a two-handed weapon from the Unholy section)**

|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Scourgelord Helmet](https://wotlk.evowow.com/?item=51312)                  | Vendor                     |
| Neck            | [Penumbra Pendant](https://wotlk.evowow.com/?item=54581)                               | Halion 25HC                |
| Shoulders       | [Sanctified Scourgelord Shoulderplates](https://wotlk.evowow.com/?item=51314)          | Vendor                     |
| Back            | [Winding Sheet](https://wotlk.evowow.com/?item=50677)                                  | Rotface 25HC               |
| Back (Alt)      | [Vereesa's Dexterity](https://wotlk.evowow.com/?item=47545)                            | TOGC 25 Insanity 50        |
| Chest           | [Sanctified Scourgelord Battleplate](https://wotlk.evowow.com/?item=51310)             | Vendor                     |
| Wrists          | [Toskk's Maximised Wristguards](https://wotlk.evowow.com/?item=50670)                  | Deathbringer Saurfang 25HC |
| Wrists (Alt)    | [Polar Bear Claw Bracers](https://wotlk.evowow.com/?item=50659)                        | Gunship Battle 25HC        |
| Hands           | [Fleshrending Gauntlets](https://wotlk.evowow.com/?item=50690)                         | Festergut 25HC             |
| Waist           | [Coldwraith Links](https://wotlk.evowow.com/?item=50620)                               | Valithria Dreamwalker 25HC |
| Legs            | [Sanctified Scourgelord Legplates](https://wotlk.evowow.com/?item=51313)               | Vendor                     |
| Feet            | [Apocalypse's Advance](https://wotlk.evowow.com/?item=54578)                           | Halion 25HC                |
| Finger          | [Might of Blight](https://wotlk.evowow.com/?item=50693)                                | Festergut 25HC             |
| Finger (Alt)    | [Skeleton Lord's Circle](https://wotlk.evowow.com/?item=50657)                         | Gunship Battle 25HC        |
| Finger          | [Ashen Band of Endless Might](https://wotlk.evowow.com/?item=52572)                    | ICC Reputation             |
| Trinket         | [Sharpened Twilight Scale](https://wotlk.evowow.com/?item=54590)                       | Halion 25HC                |
| Trinket         | [Deathbringer's Will](https://wotlk.evowow.com/?item=50363)                            | Deathbringer Saurfang 25HC |
| Main Hand       | [Havoc's Call, Blade of Lordaeron Kings](https://wotlk.evowow.com/?item=50737)         | Lich King 25HC             |
| Main Hand (Alt) | [Bloodvenom Blade](https://wotlk.evowow.com/?item=50672)                               | Deathbringer Saurfang 25HC |
| Off Hand        | [Havoc's Call, Blade of Lordaeron Kings](https://wotlk.evowow.com/?item=50737)         | Lich King 25HC             |
| Off Hand (Alt)  | [Bloodvenom Blade](https://wotlk.evowow.com/?item=50672)                               | Deathbringer Saurfang 25HC |
| Sigil           | [Sigil of the Hanged Man](https://wotlk.evowow.com/?item=50459)                        | Vendor                     |

## Unholy Death Knight
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Scourgelord Helmet](https://wotlk.evowow.com/?item=51312)                  | Vendor                     |
| Neck            | [Penumbra Pendant](https://wotlk.evowow.com/?item=54581)                               | Halion 25HC                |
| Shoulders       | [Sanctified Scourgelord Shoulderplates](https://wotlk.evowow.com/?item=51314)          | Vendor                     |
| Back            | [Winding Sheet](https://wotlk.evowow.com/?item=50677)                                  | Rotface 25HC               |
| Back (Alt)      | [Vereesa's Dexterity](https://wotlk.evowow.com/?item=47545)                            | TOGC 25 Insanity 50        |
| Chest           | [Sanctified Scourgelord Battleplate](https://wotlk.evowow.com/?item=51310)             | Vendor                     |
| Wrists          | [Toskk's Maximised Wristguards](https://wotlk.evowow.com/?item=50670)                  | Deathbringer Saurfang 25HC |
| Wrists (Alt)    | [Polar Bear Claw Bracers](https://wotlk.evowow.com/?item=50659)                        | Gunship Battle 25HC        |
| Hands           | [Fleshrending Gauntlets](https://wotlk.evowow.com/?item=50690)                         | Festergut 25HC             |
| Waist           | [Coldwraith Links](https://wotlk.evowow.com/?item=50620)                               | Valithria Dreamwalker 25HC |
| Legs            | [Sanctified Scourgelord Legplates](https://wotlk.evowow.com/?item=51313)               | Vendor                     |
| Feet            | [Apocalypse's Advance](https://wotlk.evowow.com/?item=54578)                           | Halion 25HC                |
| Finger          | [Might of Blight](https://wotlk.evowow.com/?item=50693)                                | Festergut 25HC             |
| Finger (Alt)    | [Skeleton Lord's Circle](https://wotlk.evowow.com/?item=50657)                         | Gunship Battle 25HC        |
| Finger          | [Ashen Band of Endless Might](https://wotlk.evowow.com/?item=52572)                    | ICC Reputation             |
| Trinket         | [Sharpened Twilight Scale](https://wotlk.evowow.com/?item=54590)                       | Halion 25HC                |
| Trinket         | [Deathbringer's Will](https://wotlk.evowow.com/?item=50363)                            | Deathbringer Saurfang 25HC |
| Main Hand       | [Shadowmourne](https://wotlk.evowow.com/?item=49623)                                   | Shadowmourne Questline     |
| Main Hand (Alt) | [Glorenzelg, High-Blade of the Silver Hand](https://wotlk.evowow.com/?item=50730)      | Lich King 25HC             |
| Sigil           | [Sigil of the Hanged Man](https://wotlk.evowow.com/?item=50459)                        | Vendor                     |

## Blood Tank Death Knight
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Scourgelord Faceguard](https://wotlk.evowow.com/?item=51306)               | Vendor                     |
| Neck            | [Bile-Encrusted Medallion](https://wotlk.evowow.com/?item=50682)                       | Rotface 25HC               |
| Shoulders       | [Sanctified Scourgelord Pauldrons](https://wotlk.evowow.com/?item=51309)               | Vendor                     |
| Back            | [Sentinel's Winter Cloak](https://wotlk.evowow.com/?item=50466)                        | Vendor                     |
| Chest           | [Sanctified Scourgelord Chestguard](https://wotlk.evowow.com/?item=51305)              | Vendor                     |
| Wrists          | [Gargoyle Spit Bracers](https://wotlk.evowow.com/?item=51901)                          | Deathbringer Saurfang 25HC |
| Hands           | [Sanctified Scourgelord Handguards](https://wotlk.evowow.com/?item=51307)              | Vendor                     |
| Waist           | [Verdigris Chain Belt](https://wotlk.evowow.com/?item=50991)                           | Vendor                     |
| Legs            | [Legguards of Lost Hope](https://wotlk.evowow.com/?item=50612)                         | Marrowgar 25HC             |
| Feet            | [Treads of Impending Resurrection](https://wotlk.evowow.com/?item=54579)               | Halion 25HC                |
| Finger          | [Devium's Eternally Cold Ring](https://wotlk.evowow.com/?item=50622)                   | Valithria Dreamwalker 25HC |
| Finger          | [Ashen Band of Endless Courage](https://wotlk.evowow.com/?item=50404)                  | Vendor                     |
| Trinket         | [Petrified Twilight Scale](https://wotlk.evowow.com/?item=54591)                       | Halion 25HC                |
| Trinket         | [Sindragosa's Flawless Fang](https://wotlk.evowow.com/?item=50364)                     | Sindragosa 25HC            |
| Trinket (Alt)   | [Unidentifiable Organ](https://wotlk.evowow.com/?item=50344)                           | Professor Putricide 10HC   |
| Trinket (Alt)   | [Corroded Skeleton Key](https://wotlk.evowow.com/?item=50356)                          | Vendor                     |
| Trinket (Alt)   | [Corpse Tongue Coin](https://wotlk.evowow.com/?item=50349)                             | Gunship Battle 25HC        |
| Main Hand       | [Shadowmourne](https://wotlk.evowow.com/?item=49623)                                   | Shadowmourne Questline     |
| Main Hand (Alt) | [Glorenzelg, High-Blade of the Silver Hand](https://wotlk.evowow.com/?item=50730)      | Lich King 25HC             |
| Sigil           | [Sigil of the Bone Gryphon](https://wotlk.evowow.com/?item=50462)                      | Vendor                     |

**Trinket Alternative Options Breakdown:**

|  Item                 | Purpose             |
|-----------------------|---------------------|
| Unidentifiable Organ  | Armor               |
| Corroded Skeleton Key | Stamina/Easy to get |
| Corpse Tongue Coin    | Avoidance           |

# Mage BiS Lists

## Fire Mage
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Bloodmage Hood](https://wotlk.evowow.com/?item=51281)                      | Vendor                     |
| Neck            | [Blood Queen's Crimson Choker](https://wotlk.evowow.com/?item=50724)                   | Blood Queen Lana'thel 25HC |
| Shoulders       | [Sanctified Bloodmage Shoulderpads](https://wotlk.evowow.com/?item=51284)              | Vendor                     |
| Back            | [Cloak of Burning Dusk](https://wotlk.evowow.com/?item=54583)                          | Halion 25HC                |
| Chest           | [Sanctified Bloodmage Robe](https://wotlk.evowow.com/?item=51283)                      | Vendor                     |
| Wrists          | [Bracers of Fiery Night](https://wotlk.evowow.com/?item=54582)                         | Halion 25HC                |
| Hands           | [Sanctified Bloodmage Gloves](https://wotlk.evowow.com/?item=51280)                    | Vendor                     |
| Waist           | [Crushing Coldwraith Belt](https://wotlk.evowow.com/?item=50613)                       | Marrowgar 25HC             |
| Legs            | [Plaguebringer's Stained Pants](https://wotlk.evowow.com/?item=50694)                  | Festergut 25HC             |
| Feet            | [Plague Scientist's Boots](https://wotlk.evowow.com/?item=50699)                       | Festergut 25HC             |
| Finger          | [Loop of the Endless Labyrinth](https://wotlk.evowow.com/?item=50614)                  | Marrowgar 25HC             |
| Finger          | [Ashen Band of Endless Destruction](https://wotlk.evowow.com/?item=50398)              | Vendor                     |
| Trinket         | [Charred Twilight Scale](https://wotlk.evowow.com/?item=54588)                         | Halion 25HC                |
| Trinket         | [Phylactery of the Nameless Lich](https://wotlk.evowow.com/?item=50365)                | Sindragosa 25HC            |
| Main Hand       | [Bloodsurge, Kel'Thuzad's Blade of Agony](https://wotlk.evowow.com/?item=50732)        | Lich King 25HC             |
| Off Hand        | [Shadow Silk Spindle](https://wotlk.evowow.com/?item=50719)                            | Prince Valanar 25HC        |
| Wand            | [Corpse-Impaling Spike](https://wotlk.evowow.com/?item=50684)                          | Rotface 25HC               |

## Arcane Mage
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Bloodmage Hood](https://wotlk.evowow.com/?item=51281)                      | Vendor                     |
| Neck            | [Blood Queen's Crimson Choker](https://wotlk.evowow.com/?item=50724)                   | Blood Queen Lana'thel 25HC |
| Shoulders       | [Sanctified Bloodmage Shoulderpads](https://wotlk.evowow.com/?item=51284)              | Vendor                     |
| Back            | [Cloak of Burning Dusk](https://wotlk.evowow.com/?item=54583)                          | Halion 25HC                |
| Chest           | [Sanctified Bloodmage Robe](https://wotlk.evowow.com/?item=51283)                      | Vendor                     |
| Wrists          | [Bracers of Fiery Night](https://wotlk.evowow.com/?item=54582)                         | Halion 25HC                |
| Hands           | [Sanctified Bloodmage Gloves](https://wotlk.evowow.com/?item=51280)                    | Vendor                     |
| Waist           | [Crushing Coldwraith Belt](https://wotlk.evowow.com/?item=50613)                       | Marrowgar 25HC             |
| Legs            | [Plaguebringer's Stained Pants](https://wotlk.evowow.com/?item=50694)                  | Festergut 25HC             |
| Feet            | [Plague Scientist's Boots](https://wotlk.evowow.com/?item=50699)                       | Festergut 25HC             |
| Finger          | [Loop of the Endless Labyrinth](https://wotlk.evowow.com/?item=50614)                  | Marrowgar 25HC             |
| Finger (Alt)    | [Ring of Rapid Ascent](https://wotlk.evowow.com/?item=50664)                           | Gunship Battle 25HC        |
| Finger          | [Ashen Band of Endless Destruction](https://wotlk.evowow.com/?item=50398)              | ICC Reputation             |
| Trinket         | [Charred Twilight Scale](https://wotlk.evowow.com/?item=54588)                         | Halion 25HC                |
| Trinket         | [Dislodged Foreign Object](https://wotlk.evowow.com/?item=50348)                       | Rotface 25HC               |
| Main Hand       | [Bloodsurge, Kel'Thuzad's Blade of Agony](https://wotlk.evowow.com/?item=50732)        | Lich King 25HC             |
| Off Hand        | [Shadow Silk Spindle](https://wotlk.evowow.com/?item=50719)                            | Prince Valanar 25HC        |
| Wand            | [Corpse-Impaling Spike](https://wotlk.evowow.com/?item=50684)                          | Rotface 25HC               |

# Paladin BIS List

## Retribution Paladin
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Lightsworn Helmet](https://wotlk.evowow.com/?item=51277)                   | Vendor                     |
| Neck            | [Penumbra Pendant](https://wotlk.evowow.com/?item=54581)                               | Halion 25HC                |
| Shoulders       | [Sanctified Lightsworn Shoulderplates](https://wotlk.evowow.com/?item=51279)           | Vendor                     |
| Back            | [Shadowvault Slayer's Cloak](https://wotlk.evowow.com/?item=50653)                     | Gunship Battle 25HC        |
| Chest           | [Sanctified Lightsworn Battleplate](https://wotlk.evowow.com/?item=51275)              | Vendor                     |
| Wrists          | [Umbrage Armbands](https://wotlk.evowow.com/?item=54580)                               | Halion 25HC                |
| Wrists (Alt)    | [Polar Bear Claw Bracers](https://wotlk.evowow.com/?item=50659)                        | Gunship Battle 25HC        |
| Hands           | [Fleshrending Gauntlets](https://wotlk.evowow.com/?item=50690)                         | Festergut 25HC             |
| Waist           | [Astrylian's Sutured Cinch](https://wotlk.evowow.com/?item=50707)                      | Professor Putricide 25HC   |
| Legs            | [Sanctified Lightsworn Legplates](https://wotlk.evowow.com/?item=51278)                | Vendor                     |
| Feet            | [Apocalypse's Advance](https://wotlk.evowow.com/?item=54578)                           | Halion 25HC                |
| Finger          | [Ashen Band of Endless Vengeance](https://wotlk.evowow.com/?item=50402)                | ICC Reputation             |
| Finger (Alt)    | [Ashen Band of Endless Might](https://wotlk.evowow.com/?item=52572)                    | ICC Reputation             |
| Finger          | [Signet of Twilight](https://wotlk.evowow.com/?item=54576)                             | Halion 25HC                |
| Finger (Alt)    | [Might of Blight](https://wotlk.evowow.com/?item=50693)                                | Festergut 25HC             |
| Trinket         | [Sharpened Twilight Scale](https://wotlk.evowow.com/?item=54590)                       | Halion 25HC                |
| Trinket         | [Tiny Abomination in a Jar](https://wotlk.evowow.com/?item=50706)                      | Professor Putricide 25HC   |
| Main Hand       | [Shadowmourne](https://wotlk.evowow.com/?item=49623)                                   | Shadowmourne Questline     |
| Main Hand (Alt) | [Glorenzelg, High-Blade of the Silver Hand](https://wotlk.evowow.com/?item=50730)      | Lich King 25HC             |
| Main Hand (Alt) | [Oathbinder, Charge of the Range-General](https://wotlk.evowow.com/?item=50735)        | Lich King 25HC             |
| Libram          | [Libram of Three Truths](https://wotlk.evowow.com/?item=50455)                         | Vendor                     |

## Holy Paladin
|  Slot           | Name                                                                                   | Source                     |
|-----------------|----------------------------------------------------------------------------------------|----------------------------|
| Head            | [Sanctified Lightsworn Headpiece](https://wotlk.evowow.com/?item=51272)                | Vendor                     |
| Neck            | [Blood Queen's Crimson Choker](https://wotlk.evowow.com/?item=50724)                   | Blood Queen Lana'thel 25HC |
| Shoulders       | [Sanctified Lightsworn Spaulders](https://wotlk.evowow.com/?item=51273)                | Vendor                     |
| Back            | [Cloak of Burning Dusk](https://wotlk.evowow.com/?item=54583)                          | Halion 25HC                |
| Chest           | [Rot-Resistant Breastplate](https://wotlk.evowow.com/?item=50680)                      | Rotface 25HC               |
| Wrists          | [Bracers of Fiery Night](https://wotlk.evowow.com/?item=54582)                         | Halion 25HC                |
| Hands           | [Fallen Lord's Handguards](https://wotlk.evowow.com/?item=50650)                       | Lady Deathwhisper 25HC     |
| Waist           | [Split Shape Belt](https://wotlk.evowow.com/?item=54587)                               | Halion 25HC                |
| Legs            | [Plaguebringer's Stained Pants](https://wotlk.evowow.com/?item=50694)                  | Festergut 25HC             |
| Feet            | [Foreshadow Steps](https://wotlk.evowow.com/?item=54586)                               | Halion 25HC                |
| Finger          | [Ring of Rapid Ascent](https://wotlk.evowow.com/?item=50664)                           | Gunship Battle 25HC        |
| Finger (Alt)    | [Ring of Phased Regeneration](https://wotlk.evowow.com/?item=54585)                    | Halion 25HC                |
| Finger          | [Ashen Band of Endless Wisdom](https://wotlk.evowow.com/?item=50400)                   | Vendor                     |
| Trinket         | [Meteorite Crystal](https://wotlk.evowow.com/?item=46051)                              | Algalon the Observer 25N   |
| Trinket         | [Talisman of Resurgence](https://wotlk.evowow.com/?item=48724)                         | EoT Vendor                 |
| Trinket (Alt)   | [Solace of the Defeated](https://wotlk.evowow.com/?item=47059)                         | Lord Jaraxxus 25HC         |
| Main Hand       | [Val'anyr, Hammer of Ancient Kings](https://wotlk.evowow.com/?item=46017)              | Ulduar Quest Line          |
| Main Hand (Alt) | [Bloodsurge, Kel'Thuzad's Blade of Agony](https://wotlk.evowow.com/?item=50732)        | Lich King 25HC             |
| Main Hand (Alt) | [Trauma](https://wotlk.evowow.com/?item=50685)                                         | Rotface 25HC               |
| Off Hand        | [Bulwark of Smouldering Steel](https://wotlk.evowow.com/?item=50616)                   | Marrowgar 25HC             |
| Libram          | [Libram of Renewal](https://wotlk.evowow.com/?item=40705)                              | Vendor                     |

## Protection Paladin
|  Slot           | Name                                                                                   | Source                     |
|-----------------|--------------------------------------------------------------------------------------- |----------------------------|
| Head            | [Broken Ram Skull Helm](https://wotlk.evowow.com/?item=50640)                          | Lady Deathwhisper 25HC     |
| Neck            | [Bile-Encrusted Medallion](https://wotlk.evowow.com/?item=50682)                       | Rotface 25HC               |
| Shoulders       | [Boneguard Commander's Pauldrons](https://wotlk.evowow.com/?item=50660)                | Gunship Battle 25HC        |
| Back            | [Sentinel's Winter Cloak](https://wotlk.evowow.com/?item=50466)                        | Vendor                     |
| Chest           | [Sanctified Lightsworn Chestguard](https://wotlk.evowow.com/?item=51265)               | Vendor                     |
| Wrists          | [Gargoyle Spit Bracers](https://wotlk.evowow.com/?item=51901)                          | Deathbringer Saurfang 25HC |
| Hands           | [Sanctified Lightsworn Handguards](https://wotlk.evowow.com/?item=51267)               | Vendor                     |
| Waist           | [Verdigris Chain Belt](https://wotlk.evowow.com/?item=50991)                           | Vendor                     |
| Legs            | [Pillars of Might](https://wotlk.evowow.com/?item=49904)                               | Crafted                    |
| Feet            | [Treads of Impending Resurrection](https://wotlk.evowow.com/?item=54579)               | Halion 25HC                |
| Finger          | [Devium's Eternally Cold Ring](https://wotlk.evowow.com/?item=50622)                   | Valithria Dreamwalker 25HC |
| Finger          | [Ashen Band of Endless Courage](https://wotlk.evowow.com/?item=50404)                  | Vendor                     |
| Trinket         | [Petrified Twilight Scale](https://wotlk.evowow.com/?item=54591)                       | Halion 25HC                |
| Trinket         | [Sindragosa's Flawless Fang](https://wotlk.evowow.com/?item=50364)                     | Sindragosa 25HC            |
| Main Hand       | [Mithrios, Bronzebeard's Legacy](https://wotlk.evowow.com/?item=50738)                 | Lich King 25HC             |
| Off Hand        | [Icecrown Glacial Wall](https://wotlk.evowow.com/?item=50729)                          | Blood Queen Lana'thel 25HC |
| Totem           | [Libram of the Eternal Tower](https://wotlk.evowow.com/?item=50461)                    | Vendor                     |

# Priest BIS List

## Shadow Priest
|  Slot           | Name                                                                                   | Source                     |
|-----------------|--------------------------------------------------------------------------------------- |----------------------------|
| Head            | [Sanctified Crimson Acolyte Cowl](https://wotlk.evowow.com/?item=51255)                | Vendor                     |
| Neck            | [Blood Queen's Crimson Choker](https://wotlk.evowow.com/?item=50724)                   | Blood Queen Lana'thel 25HC |
| Shoulders       | [Sanctified Crimson Acolyte Mantle](https://wotlk.evowow.com/?item=51257)              | Vendor                     |
| Back            | [Cloak of Burning Dusk](https://wotlk.evowow.com/?item=54583)                          | Halion 25HC                |
| Chest           | [Sanctified Crimson Acolyte Raiments](https://wotlk.evowow.com/?item=51259)            | Vendor                     |
| Wrists          | [Bracers of Fiery Night](https://wotlk.evowow.com/?item=54582)                         | Halion 25HC                |
| Hands           | [Sanctified Crimson Acolyte Handwraps](https://wotlk.evowow.com/?item=51256)           | Vendor                     |
| Waist           | [Crushing Coldwraith Belt](https://wotlk.evowow.com/?item=50613)                       | Marrowgar 25HC             |
| Legs            | [Plaguebringer's Stained Pants](https://wotlk.evowow.com/?item=50694)                  | Festergut 25HC             |
| Feet            | [Plague Scientist's Boots](https://wotlk.evowow.com/?item=50699)                       | Festergut 25HC             |
| Finger          | [Ring of Rapid Ascent](https://wotlk.evowow.com/?item=50664)                           | Gunship Battle 25HC        |
| Finger          | [Ashen Band of Endless Destruction](https://wotlk.evowow.com/?item=50398)              | Vendor                     |
| Trinket         | [Charred Twilight Scale](https://wotlk.evowow.com/?item=54588)                         | Halion 25HC                |
| Trinket         | [Dislodged Foreign Object](https://wotlk.evowow.com/?item=50348)                       | Rotface 25HC               |
| Main Hand       | [Royal Scepter of Terenas II](https://wotlk.evowow.com/?item=50734)                    | Lich King 25HC             |
| Off Hand        | [Shadow Silk Spindle](https://wotlk.evowow.com/?item=50719)                            | Prince Valanar 25HC        |
| Wand            | [Corpse-Impaling Spike](https://wotlk.evowow.com/?item=50684)                          | Rotface 25HC               |

## Discipline Priest

|  Slot           | Name                                                                                   | Source                     |
|-----------------|--------------------------------------------------------------------------------------- |----------------------------|
| Head            | [Sanctified Crimson Acolyte Hood](https://wotlk.evowow.com/?item=51261)                | Vendor                     |
| Neck            | [Blood Queen's Crimson Choker](https://wotlk.evowow.com/?item=50724)                   | Blood Queen Lana'thel 25HC |
| Shoulders       | [Sanctified Crimson Acolyte Shoulderpads](https://wotlk.evowow.com/?item=51264)        | Vendor                     |
| Back            | [Cloak of Burning Dusk](https://wotlk.evowow.com/?item=54583)                          | Halion 25HC                |
| Chest           | [Sanctified Crimson Acolyte Robe](https://wotlk.evowow.com/?item=51263)                | Vendor                     |
| Wrists          | [Bracers of Fiery Night](https://wotlk.evowow.com/?item=54582)                         | Halion 25HC                |
| Hands           | [San'layn Ritualist Gloves](https://wotlk.evowow.com/?item=50722)                      | Prince Valanar 25HC        |
| Waist           | [Crushing Coldwraith Belt](https://wotlk.evowow.com/?item=50613)                       | Marrowgar 25HC             |
| Legs            | [Sanctified Crimson Acolyte Leggings](https://wotlk.evowow.com/?item=51262)            | Vendor                     |
| Feet            | [Plague Scientist's Boots](https://wotlk.evowow.com/?item=50699)                       | Festergut 25HC             |
| Finger          | [Ring of Maddening Whispers](https://wotlk.evowow.com/?item=50644)                     | Lady Deathwhisper 25HC     |
| Finger          | [Memory of Malygos](https://wotlk.evowow.com/?item=50636)                              | Sindragosa 25HC            |
| Trinket         | [Althor's Abacus](https://wotlk.evowow.com/?item=50366)                                | Gunship Battle 25HC        |
| Trinket         | [Glowing Twilight Scale](https://wotlk.evowow.com/?item=54589)                         | Halion 25HC                |
| Main Hand       | [Royal Scepter of Terenas II](https://wotlk.evowow.com/?item=50734)                    | Lich King 25HC             |
| Off Hand        | [Shadow Silk Spindle](https://wotlk.evowow.com/?item=50719)                            | Prince Valanar 25HC        |
| Wand            | [Nightmare Ender](https://wotlk.evowow.com/?item=50631)                                | Valithria Dreamwalker 25HC |
| Wand (Alt)      | [Corpse-Impaling Spike](https://wotlk.evowow.com/?item=50684)                          | Rotface 25HC               |

## Holy Priest

|  Slot           | Name                                                                                   | Source                     |
|-----------------|--------------------------------------------------------------------------------------- |----------------------------|
| Head            | [Sanctified Crimson Acolyte Hood](https://wotlk.evowow.com/?item=51261)                | Vendor                     |
| Neck            | [Bone Sentinel's Amulet](https://wotlk.evowow.com/?item=50609)                         | Marrowgar 25HC             |
| Shoulders       | [Sanctified Crimson Acolyte Shoulderpads](https://wotlk.evowow.com/?item=51264)        | Vendor                     |
| Back            | [Greatcloak of the Turned Champion](https://wotlk.evowow.com/?item=50668)              | Deathbringer Saurfang 25HC |
| Chest           | [Sanguine Silk Robes](https://wotlk.evowow.com/?item=50717)                            | Prince Valanar 25HC        |
| Wrists          | [Bracers of Fiery Night](https://wotlk.evowow.com/?item=54582)                         | Halion 25HC                |
| Hands           | [Sanctified Crimson Acolyte Gloves](https://wotlk.evowow.com/?item=51260)              | Vendor                     |
| Waist           | [Lingering Illness](https://wotlk.evowow.com/?item=50702)                              | Festergut 25HC             |
| Legs            | [Sanctified Crimson Acolyte Leggings](https://wotlk.evowow.com/?item=51262)            | Vendor                     |
| Feet            | [Plague Scientist's Boots](https://wotlk.evowow.com/?item=50699)                       | Festergut 25HC             |
| Finger          | [Ashen Band of Endless Wisdom](https://wotlk.evowow.com/?item=50400)                   | Vendor                     |
| Finger          | [Memory of Malygos](https://wotlk.evowow.com/?item=50636)                              | Sindragosa 25HC            |
| Trinket         | [Althor's Abacus](https://wotlk.evowow.com/?item=50366)                                | Gunship Battle 25HC        |
| Trinket         | [Glowing Twilight Scale](https://wotlk.evowow.com/?item=54589)                         | Halion 25HC                |
| Main Hand       | [Archus, Greatstaff of Antonidas](https://wotlk.evowow.com/?item=50731)                | Lich King 25HC             |
| Wand            | [Nightmare Ender](https://wotlk.evowow.com/?item=50631)                                | Valithria Dreamwalker 25HC |

# Rogue BIS List

## Combat Rogue

|  Slot           | Name                                                                                   | Source                     |
|-----------------|--------------------------------------------------------------------------------------- |----------------------------|
| Head            | [Sanctified Shadowblade Helmet](https://wotlk.evowow.com/?item=51252)                  | Vendor                     |
| Neck            | [Sindragosa's Cruel Claw](https://wotlk.evowow.com/?item=50633)                        | Sindragosa 25HC            |
| Shoulders       | [Sanctified Shadowblade Pauldrons](https://wotlk.evowow.com/?item=51254)               | Vendor                     |
| Back            | [Vereesa's Dexterity](https://wotlk.evowow.com/?item=47545)                            | TOGC 25 Insanity 50        |
| Back (Alt)      | [Recovered Scarlet Onslaught Cape](https://wotlk.evowow.com/?item=50470)               | Vendor                     |
| Chest           | [Sanctified Shadowblade Breastplate](https://wotlk.evowow.com/?item=51250)             | Vendor                     |
| Wrists          | [Toskk's Maximised Wristguards](https://wotlk.evowow.com/?item=50670)                  | Deathbringer Saurfang 25HC |
| Hands           | [Aldriana's Gloves of Secrecy](https://wotlk.evowow.com/?item=50675)                   | Rotface 25HC               |
| Waist           | [Astrylian's Sutured Cinch](https://wotlk.evowow.com/?item=50707)                      | Professor Putricide 25HC   |
| Legs            | [Sanctified Shadowblade Legplates](https://wotlk.evowow.com/?item=51253)               | Vendor                     |
| Feet            | [Frostbitten Fur Boots](https://wotlk.evowow.com/?item=50607)                          | Marrowgar 25HC             |
| Finger          | [Ashen Band of Endless Vengeance](https://wotlk.evowow.com/?item=50402)                | ICC Reputation             |
| Finger          | [Frostbrood Sapphire Ring](https://wotlk.evowow.com/?item=50618)                       | Valithria Dreamwalker 25HC |
| Trinket         | [Deathbringer's Will](https://wotlk.evowow.com/?item=50363)                            | Deathbringer Saurfang 25HC |
| Trinket         | [Sharpened Twilight Scale](https://wotlk.evowow.com/?item=54590)                       | Halion 25HC                |
| Main Hand       | [Havoc's Call, Blade of Lordaeron Kings](https://wotlk.evowow.com/?item=50737)         | Lich King 25HC             |
| Off Hand        | [Scourgeborne Waraxe](https://wotlk.evowow.com/?item=50654)                            | Gunship Battle 25HC        |
| Ranged          | [Fal'inrush, Defender of Quel'thalas](https://wotlk.evowow.com/?item=50733)            | Lich King 25HC             |

## Assassination Rogue

|  Slot           | Name                                                                                   | Source                     |
|-----------------|--------------------------------------------------------------------------------------- |----------------------------|
| Head            | [Geistlord's Punishment Sack](https://wotlk.evowow.com/?item=50713)                    | Prince Valanar 25HC        |
| Neck            | [Sindragosa's Cruel Claw](https://wotlk.evowow.com/?item=50633)                        | Sindragosa 25HC            |
| Shoulders       | [Cultist's Bloodsoaked Spaulders](https://wotlk.evowow.com/?item=50646)                | Lady Deathwhisper 25HC     |
| Back            | [Shadowvault Slayer's Cloak](https://wotlk.evowow.com/?item=50653)                     | Gunship Battle 25HC        |
| Chest           | [Ikfirus's Sack of Wonder](https://wotlk.evowow.com/?item=50656)                       | Gunship Battle 25HC        |
| Wrists          | [Umbrage Armbands](https://wotlk.evowow.com/?item=54580)                               | Halion 25HC                |
| Hands           | [Sanctified Shadowblades Gauntlets](https://wotlk.evowow.com/?item=51251)              | Vendor                     |
| Waist           | [Belt of the Merciless Killer](https://wotlk.evowow.com/?item=47112)                   | Fjola Lightbane 25HC       |
| Waist (Alt)     | [Astrylian's Sutured Cinch](https://wotlk.evowow.com/?item=50707)                      | Professor Putricide 25HC   |
| Legs            | [Sanctified Shadowblade Legplates](https://wotlk.evowow.com/?item=51253)               | Vendor                     |
| Feet            | [Frostbitten Fur Boots](https://wotlk.evowow.com/?item=50607)                          | Marrowgar 25HC             |
| Finger          | [Ashen Band of Endless Vengeance](https://wotlk.evowow.com/?item=50402)                | ICC Reputation             |
| Finger (Alt)    | [Signet of Twilight](https://wotlk.evowow.com/?item=54576)                             | Halion 25HC                |
| Trinket         | [Sharpened Twilight Scale](https://wotlk.evowow.com/?item=54590)                       | Halion 25HC                |
| Trinket         | [Tiny Abomination in a Jar](https://wotlk.evowow.com/?item=50706)                      | Professor Putricide 25HC   |
| Main Hand       | [Heaven's Fall, Kryss of a Thousand Lies](https://wotlk.evowow.com/?item=50736)        | Lich King 25HC             |
| Off Hand        | [Lungbreaker](https://wotlk.evowow.com/?item=50621)                                    | Valtheria Dreamwalker 25HC |
| Ranged          | [Fal'inrush, Defender of Quel'thalas](https://wotlk.evowow.com/?item=50733)            | Lich King 25HC             |

## Template
|  Slot           | Name                                                                                   | Source                     |
|-----------------|--------------------------------------------------------------------------------------- |----------------------------|
| Head            | []()                                                                                   |                            |
| Neck            | []()                                                                                   |                            |
| Shoulders       | []()                                                                                   |                            |
| Back            | []()                                                                                   |                            |
| Chest           | []()                                                                                   |                            |
| Wrists          | []()                                                                                   |                            |
| Hands           | []()                                                                                   |                            |
| Waist           | []()                                                                                   |                            |
| Legs            | []()                                                                                   |                            |
| Feet            | []()                                                                                   |                            |
| Finger          | []()                                                                                   |                            |
| Finger          | []()                                                                                   |                            |
| Trinket         | []()                                                                                   |                            |
| Trinket         | []()                                                                                   |                            |
| Main Hand       | []()                                                                                   |                            |
| Off Hand        | []()                                                                                   |                            |
| Totem           | []()                                                                                   |                            |
